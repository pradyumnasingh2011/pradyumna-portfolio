import pygame, sys, time, random, json
import os

# Difficulty
difficulty = int(input("enter number of dificulty:"))

# Window size
frame_size_x = 720
frame_size_y = 480

# Initialize pygame
check_errors = pygame.init()
if check_errors[1] > 0:
    print(f'[!] Had {check_errors[1]} errors when initializing game, exiting...')
    sys.exit(-1)

# Load/Create high score file
high_score_file = "high_scores.json"
if not os.path.exists(high_score_file):
    with open(high_score_file, "w") as f:
        json.dump({"name": "None", "score": 0}, f)

# Ask player name
player_name = input("Enter your name: ")

# Load high score
with open(high_score_file, "r") as f:
    high_score_data = json.load(f)
    high_scorer = high_score_data["name"]
    high_score = high_score_data["score"]

# Initialize window
pygame.display.set_caption('Snake Eater')
game_window = pygame.display.set_mode((frame_size_x, frame_size_y))

# Colors
black = pygame.Color(0, 0, 0)
white = pygame.Color(255, 255, 255)
red = pygame.Color(255, 0, 0)
green = pygame.Color(0, 255, 0)

# Clock
fps_controller = pygame.time.Clock()

# Snake & Food init
snake_pos = [100, 50]
snake_body = [[100, 50], [90, 50], [80, 50]]

food_pos = [random.randrange(1, (frame_size_x // 10)) * 10,
            random.randrange(1, (frame_size_y // 10)) * 10]
food_spawn = True

direction = 'RIGHT'
change_to = direction

score = 0

# Score display
def show_score(choice, color, font, size):
    score_font = pygame.font.SysFont(font, size)
    score_surface = score_font.render(
        f'Score: {score} | High Score: {high_score} ({high_scorer})', True, color)
    score_rect = score_surface.get_rect()
    if choice == 1:
        score_rect.topleft = (10, 10)
    else:
        score_rect.midtop = (frame_size_x / 2, frame_size_y / 4)
    game_window.blit(score_surface, score_rect)

# Game over
def game_over():
    global high_score, high_scorer
    if score > high_score:
        high_score = score
        high_scorer = player_name
        with open(high_score_file, "w") as f:
            json.dump({"name": high_scorer, "score": high_score}, f)

    font = pygame.font.SysFont('times new roman', 70)
    surface = font.render('YOU DIED', True, red)
    rect = surface.get_rect()
    rect.midtop = (frame_size_x / 2, frame_size_y / 4)
    game_window.fill(black)
    game_window.blit(surface, rect)
    show_score(0, red, 'times new roman', 20)
    pygame.display.flip()
    time.sleep(3)
    pygame.quit()
    sys.exit()

# Main game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key in [pygame.K_UP, ord('w')]:
                change_to = 'UP'
            if event.key in [pygame.K_DOWN, ord('s')]:
                change_to = 'DOWN'
            if event.key in [pygame.K_LEFT, ord('a')]:
                change_to = 'LEFT'
            if event.key in [pygame.K_RIGHT, ord('d')]:
                change_to = 'RIGHT'
            if event.key == pygame.K_ESCAPE:
                pygame.event.post(pygame.event.Event(pygame.QUIT))

    # Direction validation
    if change_to == 'UP' and direction != 'DOWN':
        direction = 'UP'
    if change_to == 'DOWN' and direction != 'UP':
        direction = 'DOWN'
    if change_to == 'LEFT' and direction != 'RIGHT':
        direction = 'LEFT'
    if change_to == 'RIGHT' and direction != 'LEFT':
        direction = 'RIGHT'

    # Move
    if direction == 'UP':
        snake_pos[1] -= 10
    if direction == 'DOWN':
        snake_pos[1] += 10
    if direction == 'LEFT':
        snake_pos[0] -= 10
    if direction == 'RIGHT':
        snake_pos[0] += 10

    # Screen Wrapping
    snake_pos[0] %= frame_size_x
    snake_pos[1] %= frame_size_y

    # Body update
    snake_body.insert(0, list(snake_pos))
    if snake_pos == food_pos:
        score += 1
        food_spawn = False
    else:
        snake_body.pop()

    # Respawn food
    if not food_spawn:
        food_pos = [random.randrange(1, (frame_size_x // 10)) * 10,
                    random.randrange(1, (frame_size_y // 10)) * 10]
    food_spawn = True

    # Graphics
    game_window.fill(black)
    for block in snake_body:
        pygame.draw.rect(game_window, green, pygame.Rect(block[0], block[1], 10, 10))
    pygame.draw.rect(game_window, white, pygame.Rect(food_pos[0], food_pos[1], 10, 10))
    show_score(1, white, 'consolas', 20)

    # Collision check (self)
    for block in snake_body[1:]:
        if snake_pos == block:
            game_over()

    pygame.display.update()
    fps_controller.tick(difficulty)
