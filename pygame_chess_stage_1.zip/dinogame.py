import pygame
import random
import json
import os
import sys

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 400
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GROUND_HEIGHT = HEIGHT - 30
FPS = 60

# Set up display
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("🦖 Dino Runner")

# Fonts
font = pygame.font.SysFont('consolas', 24)

# Player name input
player_name = input("Enter your name: ")

# High Score File
hs_file = "scores.json"
if not os.path.exists(hs_file):
    with open(hs_file, "w") as f:
        json.dump({"name": "None", "score": 0}, f)

with open(hs_file, "r") as f:
    hs_data = json.load(f)
    high_score = hs_data["score"]
    high_scorer = hs_data["name"]

# Dino properties
dino_width, dino_height = 40, 40
dino_x = 50
dino_y = GROUND_HEIGHT - dino_height
dino_vel_y = 0
gravity = 0.8
jump_strength = -14
is_jumping = False

# Obstacle properties
obstacles = []
obstacle_timer = 0
obstacle_freq = 1500  # milliseconds
obstacle_width = 20
obstacle_height = 40
game_speed = 6

# Score
score = 0
clock = pygame.time.Clock()

# Game Over
def game_over():
    global high_score, high_scorer
    if score > high_score:
        high_score = score
        high_scorer = player_name
        with open(hs_file, "w") as f:
            json.dump({"name": player_name, "score": score}, f)

    msg = font.render("You crashed! Press R to Retry or ESC to Exit", True, BLACK)
    win.blit(msg, (WIDTH // 2 - msg.get_width() // 2, HEIGHT // 2))
    pygame.display.update()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    return True  # retry
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit(); sys.exit()
        clock.tick(10)

# Main Game Loop
def main():
    global dino_y, dino_vel_y, is_jumping, obstacles, obstacle_timer, game_speed, score

    dino_y = GROUND_HEIGHT - dino_height
    dino_vel_y = 0
    is_jumping = False
    obstacles = []
    obstacle_timer = pygame.time.get_ticks()
    game_speed = 6
    score = 0

    running = True
    while running:
        win.fill(WHITE)
        pygame.draw.line(win, BLACK, (0, GROUND_HEIGHT), (WIDTH, GROUND_HEIGHT), 2)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_SPACE, pygame.K_UP] and not is_jumping:
                    dino_vel_y = jump_strength
                    is_jumping = True

        # Dino jump logic
        dino_vel_y += gravity
        dino_y += dino_vel_y
        if dino_y >= GROUND_HEIGHT - dino_height:
            dino_y = GROUND_HEIGHT - dino_height
            is_jumping = False

        pygame.draw.rect(win, BLACK, (dino_x, dino_y, dino_width, dino_height))

        # Spawn obstacles
        if pygame.time.get_ticks() - obstacle_timer > obstacle_freq:
            obstacle_timer = pygame.time.get_ticks()
            obstacle_x = WIDTH
            obstacles.append([obstacle_x, GROUND_HEIGHT - obstacle_height])

        # Move and draw obstacles
        for obstacle in obstacles:
            obstacle[0] -= game_speed
            pygame.draw.rect(win, (200, 0, 0), (obstacle[0], obstacle[1], obstacle_width, obstacle_height))

        # Remove off-screen obstacles
        obstacles = [ob for ob in obstacles if ob[0] + obstacle_width > 0]

        # Collision detection
        for ob in obstacles:
            if dino_x < ob[0] + obstacle_width and dino_x + dino_width > ob[0] and dino_y + dino_height > ob[1]:
                if not game_over():
                    return

                # Reset game
                return main()

        # Increase score and speed
        score += 1
        if score % 200 == 0:
            game_speed += 0.5

        # Show score & high score
        score_surface = font.render(f"Score: {score} | High: {high_score} ({high_scorer})", True, BLACK)
        win.blit(score_surface, (10, 10))

        pygame.display.update()
        clock.tick(FPS)

main()
