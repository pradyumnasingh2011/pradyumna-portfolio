"""
pygame_chess_stage1_bot.py
Stage 1+Bot: Pygame GUI chess with a simple AI (minimax) and Unicode piece symbols

Features:
- 8x8 board rendered with pygame
- Pieces drawn using Unicode chess symbols (♔ ♚ etc.) — includes clear king symbols
- Click to select a piece, click a destination to move
- Legal move generation for all piece types (no castling/en-passant yet)
- Highlights legal moves and last move
- Turn enforcement (white human vs black bot by default)
- Basic check/checkmate detection
- Simple AI using minimax with alpha-beta pruning (configurable depth)
- Undo last move (press U)
- Change AI depth during game: press + to increase, - to decrease

Requirements:
    pip install pygame

Run:
    python pygame_chess_stage1_bot.py

Controls:
- Left-click to select and move
- U : undo last move
- +/- : increase / decrease AI search depth
- ESC or close window: quit

Notes:
- Pawn promotion auto-promotes to Queen for simplicity
- Castling and en-passant are not implemented in this stage
- AI is intentionally basic (material evaluation). Depth 2-3 is responsive on most machines.
"""

import pygame
from copy import deepcopy
import sys
import time

# --- Configuration ---
WIDTH, HEIGHT = 640, 640
SQUARE = WIDTH // 8
FPS = 60
AI_DEFAULT_DEPTH = 2

FILES = 'abcdefgh'
RANKS = '12345678'

# Colors
WHITE = (245,245,245)
BLACK = (20,20,20)
WOOD1 = (240, 217, 181)
WOOD2 = (181, 136, 99)
HIGHLIGHT = (50, 205, 50)
MOVE_HIGHLIGHT = (65,105,225)
LAST_MOVE = (255,215,0)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Chess — Play vs Bot (Stage: GUI + Bot)')
clock = pygame.time.Clock()
font = pygame.font.SysFont('dejavusans', SQUARE//2)  # supports unicode chess symbols
small_font = pygame.font.SysFont('arial', 16)

# Unicode symbols for pieces
UNICODE = {
    'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
    'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
}

# --- Board & rules engine ---

def init_board():
    board = [['.' for _ in range(8)] for _ in range(8)]
    order = ['r','n','b','q','k','b','n','r']
    board[0] = [c for c in ''.join(order)]
    board[1] = ['p']*8
    board[6] = ['P']*8
    board[7] = [c.upper() for c in order]
    return board

board = init_board()

def on_board(r,c):
    return 0 <= r < 8 and 0 <= c < 8

def piece_color(piece):
    if piece == '.': return None
    return 'white' if piece.isupper() else 'black'

ROOK_DIRS   = [(1,0),(-1,0),(0,1),(0,-1)]
BISHOP_DIRS = [(1,1),(1,-1),(-1,1),(-1,-1)]
QUEEN_DIRS  = ROOK_DIRS + BISHOP_DIRS
KNIGHT_DELTAS = [(2,1),(2,-1),(-2,1),(-2,-1),(1,2),(1,-2),(-1,2),(-1,-2)]

PIECE_VALUES = {'K': 900, 'Q': 90, 'R': 50, 'B': 30, 'N': 30, 'P': 10,
                'k': -900, 'q': -90, 'r': -50, 'b': -30, 'n': -30, 'p': -10}


def generate_moves(board, r, c):
    piece = board[r][c]
    if piece == '.': return []
    moves = []
    white = piece.isupper()

    if piece.lower() == 'p':
        direction = -1 if white else 1
        start_row = 6 if white else 1
        if on_board(r+direction, c) and board[r+direction][c] == '.':
            moves.append((r+direction, c))
            if r == start_row and board[r+2*direction][c] == '.':
                moves.append((r+2*direction, c))
        for dc in (-1, 1):
            nr, nc = r+direction, c+dc
            if on_board(nr,nc) and board[nr][nc] != '.' and piece_color(board[nr][nc]) != piece_color(piece):
                moves.append((nr,nc))
    elif piece.lower() == 'n':
        for dr,dc in KNIGHT_DELTAS:
            nr, nc = r+dr, c+dc
            if on_board(nr,nc):
                if board[nr][nc] == '.' or piece_color(board[nr][nc]) != piece_color(piece):
                    moves.append((nr,nc))
    elif piece.lower() == 'b':
        for dr,dc in BISHOP_DIRS:
            nr, nc = r+dr, c+dc
            while on_board(nr,nc):
                if board[nr][nc] == '.':
                    moves.append((nr,nc))
                else:
                    if piece_color(board[nr][nc]) != piece_color(piece):
                        moves.append((nr,nc))
                    break
                nr += dr; nc += dc
    elif piece.lower() == 'r':
        for dr,dc in ROOK_DIRS:
            nr, nc = r+dr, c+dc
            while on_board(nr,nc):
                if board[nr][nc] == '.':
                    moves.append((nr,nc))
                else:
                    if piece_color(board[nr][nc]) != piece_color(piece):
                        moves.append((nr,nc))
                    break
                nr += dr; nc += dc
    elif piece.lower() == 'q':
        for dr,dc in QUEEN_DIRS:
            nr, nc = r+dr, c+dc
            while on_board(nr,nc):
                if board[nr][nc] == '.':
                    moves.append((nr,nc))
                else:
                    if piece_color(board[nr][nc]) != piece_color(piece):
                        moves.append((nr,nc))
                    break
                nr += dr; nc += dc
    elif piece.lower() == 'k':
        for dr in (-1,0,1):
            for dc in (-1,0,1):
                if dr==0 and dc==0: continue
                nr, nc = r+dr, c+dc
                if on_board(nr,nc):
                    if board[nr][nc] == '.' or piece_color(board[nr][nc]) != piece_color(piece):
                        moves.append((nr,nc))
    return moves


def find_king(bd, white):
    target = 'K' if white else 'k'
    for r in range(8):
        for c in range(8):
            if bd[r][c] == target:
                return r,c
    return None


def is_in_check(bd, white):
    kr = find_king(bd, white)
    if not kr: return True
    kr_r, kr_c = kr
    for r in range(8):
        for c in range(8):
            p = bd[r][c]
            if p == '.': continue
            if piece_color(p) == ('white' if white else 'black'): continue
            for nr,nc in generate_moves(bd, r, c):
                if nr == kr_r and nc == kr_c:
                    if p.lower() == 'p':
                        dirp = -1 if p.isupper() else 1
                        if r + dirp == kr_r and abs(c - kr_c) == 1:
                            return True
                    else:
                        return True
    return False


def moves_for_player(bd, white):
    moves = []
    for r in range(8):
        for c in range(8):
            p = bd[r][c]
            if p == '.': continue
            if p.isupper() != white: continue
            for (nr,nc) in generate_moves(bd, r, c):
                newb = deepcopy(bd)
                newb[nr][nc] = newb[r][c]
                newb[r][c] = '.'
                if newb[nr][nc] == 'P' and nr == 0:
                    newb[nr][nc] = 'Q'
                if newb[nr][nc] == 'p' and nr == 7:
                    newb[nr][nc] = 'q'
                if not is_in_check(newb, white):
                    moves.append((r,c,nr,nc))
    return moves

# --- Simple evaluation & AI (minimax w/ alpha-beta) ---

def evaluate(bd):
    # simple material-based evaluation from white's perspective
    score = 0
    for r in range(8):
        for c in range(8):
            p = bd[r][c]
            if p == '.': continue
            if p in PIECE_VALUES:
                score += PIECE_VALUES[p]
    return score


def apply_move_on(bd, move):
    fr,fc,tr,tc = move
    piece = bd[fr][fc]
    captured = bd[tr][tc]
    bd[tr][tc] = piece
    bd[fr][fc] = '.'
    # auto-promotion
    if bd[tr][tc] == 'P' and tr == 0:
        bd[tr][tc] = 'Q'
    if bd[tr][tc] == 'p' and tr == 7:
        bd[tr][tc] = 'q'
    return captured


def undo_move_on(bd, move, captured, original_piece=None):
    fr,fc,tr,tc = move
    bd[fr][fc] = bd[tr][tc] if original_piece is None else original_piece
    bd[tr][tc] = captured


def minimax(bd, depth, alpha, beta, maximizing_player):
    # Terminal checks: checkmate or stalemate
    white = maximizing_player
    legal = moves_for_player(bd, white)
    if depth == 0 or not legal:
        return evaluate(bd), None

    best_move = None
    if maximizing_player:
        max_eval = -10**9
        for m in legal:
            captured = apply_move_on(bd, m)
            val, _ = minimax(bd, depth-1, alpha, beta, False)
            undo_move_on(bd, m, captured)
            if val > max_eval:
                max_eval = val
                best_move = m
            alpha = max(alpha, val)
            if beta <= alpha:
                break
        return max_eval, best_move
    else:
        min_eval = 10**9
        for m in legal:
            captured = apply_move_on(bd, m)
            val, _ = minimax(bd, depth-1, alpha, beta, True)
            undo_move_on(bd, m, captured)
            if val < min_eval:
                min_eval = val
                best_move = m
            beta = min(beta, val)
            if beta <= alpha:
                break
        return min_eval, best_move


def bot_find_move(bd, depth):
    # bot plays as black (minimizer)
    # if no legal moves, return None
    legal = moves_for_player(bd, False)
    if not legal:
        return None
    # We call minimax with maximizing_player=False because bot is black
    start = time.time()
    val, move = minimax(bd, depth, -10**9, 10**9, False)
    # print(f"AI eval={val}, time={time.time()-start:.2f}s")
    return move

# --- Helper functions for UI ---

def coord_from_mouse(pos):
    x,y = pos
    col = x // SQUARE
    row = y // SQUARE
    return row, col

def draw_board(surface, bd, selected, legal_moves, last_move):
    # squares
    for r in range(8):
        for c in range(8):
            rect = pygame.Rect(c*SQUARE, r*SQUARE, SQUARE, SQUARE)
            color = WOOD1 if (r+c)%2==0 else WOOD2
            pygame.draw.rect(surface, color, rect)

    # last move highlight
    if last_move:
        fr,fc,tr,tc = last_move
        pygame.draw.rect(surface, LAST_MOVE, pygame.Rect(fc*SQUARE, fr*SQUARE, SQUARE, SQUARE), 4)
        pygame.draw.rect(surface, LAST_MOVE, pygame.Rect(tc*SQUARE, tr*SQUARE, SQUARE, SQUARE), 4)

    # legal move highlights
    if selected is not None:
        for (mr,mc) in legal_moves:
            center = (mc*SQUARE + SQUARE//2, mr*SQUARE + SQUARE//2)
            pygame.draw.circle(surface, MOVE_HIGHLIGHT, center, SQUARE//8)

    # pieces
    for r in range(8):
        for c in range(8):
            p = bd[r][c]
            if p != '.':
                center = (c*SQUARE + SQUARE//2, r*SQUARE + SQUARE//2)
                text = UNICODE.get(p, p)
                piece_text = font.render(text, True, BLACK if p.isupper() else WHITE)
                text_rect = piece_text.get_rect(center=center)
                surface.blit(piece_text, text_rect)

    # selected border
    if selected is not None:
        sr, sc = selected
        pygame.draw.rect(surface, HIGHLIGHT, pygame.Rect(sc*SQUARE, sr*SQUARE, SQUARE, SQUARE), 4)

    # coordinates on edges
    for i in range(8):
        # files bottom
        txt = small_font.render(FILES[i], True, BLACK)
        screen.blit(txt, (i*SQUARE + 4, HEIGHT-18))
        # ranks left
        txt2 = small_font.render(str(8-i), True, BLACK)
        screen.blit(txt2, (4, i*SQUARE + 4))


# --- Game state ---
selected = None
legal_moves = []
turn_white = True
history = []  # store (fr,fc,tr,tc,captured)
last_move = None
ai_depth = AI_DEFAULT_DEPTH
human_vs_ai = True  # True: human is white, bot is black

# --- Main loop ---

def main_loop():
    global selected, legal_moves, board, turn_white, history, last_move, ai_depth
    running = True
    thinking = False
    while running:
        clock.tick(FPS)

        # If it's bot's turn and playing vs AI, compute move
        if human_vs_ai and not turn_white:
            thinking = True
            move = bot_find_move(board, ai_depth)
            thinking = False
            if move is None:
                legal = moves_for_player(board, False)
                if not legal:
                    if is_in_check(board, False):
                        print("Checkmate! White wins.")
                    else:
                        print("Stalemate!")
                running = False
            else:
                fr,fc,tr,tc = move
                captured = board[tr][tc]
                board[tr][tc] = board[fr][fc]
                board[fr][fc] = '.'
                if board[tr][tc] == 'p' and tr == 7:
                    board[tr][tc] = 'q'
                history.append((fr,fc,tr,tc,captured))
                last_move = (fr,fc,tr,tc)
                turn_white = True

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if human_vs_ai and not turn_white:
                    # ignore clicks while bot's turn
                    continue
                pos = pygame.mouse.get_pos()
                r,c = coord_from_mouse(pos)
                if not on_board(r,c):
                    continue
                if selected is None:
                    if board[r][c] == '.':
                        continue
                    if board[r][c].isupper() != turn_white:
                        continue
                    # select
                    selected = (r,c)
                    # compute legal target moves for display
                    legal_moves = []
                    for (nr,nc) in generate_moves(board, r, c):
                        newb = deepcopy(board)
                        newb[nr][nc] = newb[r][c]
                        newb[r][c] = '.'
                        if newb[nr][nc] == 'P' and nr == 0:
                            newb[nr][nc] = 'Q'
                        if newb[nr][nc] == 'p' and nr == 7:
                            newb[nr][nc] = 'q'
                        if not is_in_check(newb, turn_white):
                            legal_moves.append((nr,nc))
                else:
                    tr,tc = r,c
                    fr,fc = selected
                    if (tr,tc) in legal_moves:
                        captured = board[tr][tc]
                        board[tr][tc] = board[fr][fc]
                        board[fr][fc] = '.'
                        if board[tr][tc] == 'P' and tr == 0:
                            board[tr][tc] = 'Q'
                        history.append((fr,fc,tr,tc,captured))
                        last_move = (fr,fc,tr,tc)
                        turn_white = not turn_white
                        selected = None
                        legal_moves = []
                        # after human move, check terminal
                        if human_vs_ai and not turn_white:
                            # bot will move on next loop iteration
                            pass
                        else:
                            legal = moves_for_player(board, turn_white)
                            if not legal:
                                if is_in_check(board, turn_white):
                                    print(f"Checkmate! { 'Black' if turn_white else 'White'} wins.")
                                else:
                                    print("Stalemate!")
                    else:
                        if (fr,fc) == (tr,tc):
                            selected = None
                            legal_moves = []
                        else:
                            if board[tr][tc] != '.' and board[tr][tc].isupper() == turn_white:
                                selected = (tr,tc)
                                legal_moves = []
                                for (nr,nc) in generate_moves(board, tr, tc):
                                    newb = deepcopy(board)
                                    newb[nr][nc] = newb[tr][tc]
                                    newb[tr][tc] = '.'
                                    if newb[nr][nc] == 'P' and nr == 0:
                                        newb[nr][nc] = 'Q'
                                    if newb[nr][nc] == 'p' and nr == 7:
                                        newb[nr][nc] = 'q'
                                    if not is_in_check(newb, turn_white):
                                        legal_moves.append((nr,nc))
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_u:  # undo
                    if history:
                        fr,fc,tr,tc,captured = history.pop()
                        board[fr][fc] = board[tr][tc]
                        board[tr][tc] = captured
                        turn_white = not turn_white
                        last_move = None
                        selected = None
                        legal_moves = []
                elif event.key == pygame.K_PLUS or event.key == pygame.K_EQUALS:
                    ai_depth += 1
                    print(f"AI depth set to {ai_depth}")
                elif event.key == pygame.K_MINUS:
                    if ai_depth > 1:
                        ai_depth -= 1
                        print(f"AI depth set to {ai_depth}")
                elif event.key == pygame.K_ESCAPE:
                    running = False

        # draw
        draw_board(screen, board, selected, legal_moves, last_move)

        # show AI status & depth
        status = f"Turn: {'White (You)' if turn_white else 'Black (Bot)'}    AI depth: {ai_depth}"
        status_surf = small_font.render(status, True, (0,0,0))
        screen.blit(status_surf, (8, 8))

        if thinking:
            thinking_surf = small_font.render('Bot thinking...', True, (200,0,0))
            screen.blit(thinking_surf, (8, 28))

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == '__main__':
    main_loop()
